import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'components/background.dart';
import 'components/birje_player.dart';
import 'managers/audio_manager.dart';
import 'managers/save_manager.dart';
import 'theme.dart';
import 'world_generator.dart';

enum GameState { menu, playing, paused, over }

/// A single milestone/achievement definition.
class Achievement {
  final String id, name;
  final int reward;
  final bool Function(BirjeGame g) test;
  const Achievement(this.id, this.name, this.reward, this.test);
}

const _achievements = [
  Achievement('first', 'First Flight', 15, _always),
  Achievement('d250', 'Fly 250m', 25, _d250),
  Achievement('d500', 'Fly 500m', 50, _d500),
  Achievement('d1000', 'Sky Voyager (1000m)', 120, _d1000),
  Achievement('s50', '50 Sparkles in a run', 60, _s50),
  Achievement('combo10', 'Combo x10', 40, _combo10),
];
bool _always(BirjeGame g) => true;
bool _d250(BirjeGame g) => g.distance >= 250;
bool _d500(BirjeGame g) => g.distance >= 500;
bool _d1000(BirjeGame g) => g.distance >= 1000;
bool _s50(BirjeGame g) => g.starsRun >= 50;
bool _combo10(BirjeGame g) => g.maxCombo >= 10;

/// Overlay keys used by the GameWidget.
class Ov {
  static const menu = 'menu', hud = 'hud', over = 'over', pause = 'pause', shop = 'shop';
}

class BirjeGame extends FlameGame with HasCollisionDetection {
  final SaveManager save = SaveManager();
  final AudioManager audio = AudioManager();
  late final WorldGenerator generator;

  // Container for everything that scrolls — clearing it resets the world.
  final Component world = Component();
  late BirjePlayer player;

  GameState state = GameState.menu;
  bool get playing => state == GameState.playing;
  bool started = false; // first tap given

  // Run stats
  double scrollSpeed = 0; // pixels/sec
  double distance = 0; // "meters"
  int score = 0;
  int starsRun = 0;
  int combo = 0;
  int maxCombo = 0;
  double comboTimer = 0;
  int earned = 0;
  int _mile = 0;

  static const double startSpeedFrac = 0.30; // of width per sec
  static const double maxSpeedFrac = 0.62;

  // Live values the HUD listens to (avoids rebuilding the whole tree).
  final scoreN = ValueNotifier<int>(0);
  final distN = ValueNotifier<int>(0);
  final comboN = ValueNotifier<int>(0);
  final shardsN = ValueNotifier<int>(0);
  final toastN = ValueNotifier<String?>(null);

  @override
  Future<void> onLoad() async {
    await save.load();
    await audio.preload();
    generator = WorldGenerator(this);
    add(SkyBackground());
    add(world);
    shardsN.value = save.shards;
    overlays.add(Ov.menu);
  }

  // ----------------------------- Flow -----------------------------
  void startRun() {
    world.removeWhere((_) => true);
    distance = 0;
    score = 0;
    starsRun = 0;
    combo = 0;
    maxCombo = 0;
    comboTimer = 0;
    earned = 0;
    _mile = 0;
    started = false;
    scrollSpeed = startSpeedFrac * size.x;

    player = BirjePlayer();
    world.add(player);
    generator.reset();

    final daily = save.claimDailyIfNew();
    if (daily > 0) _toast('🎁 Daily gift  +$daily sparkles');
    shardsN.value = save.shards;

    state = GameState.playing;
    overlays
      ..remove(Ov.menu)
      ..remove(Ov.over)
      ..remove(Ov.shop)
      ..add(Ov.hud);
    _pushHud();
  }

  void onScreenTap() {
    if (!playing) return;
    started = true;
    player.flap();
    audio.flap();
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!playing) return;

    // difficulty ramp
    scrollSpeed = (startSpeedFrac * size.x + distance * 0.00012 * size.x)
        .clamp(0.0, maxSpeedFrac * size.x);

    if (started) {
      distance += scrollSpeed * dt / (size.x * 0.16);
      generator.tick(dt);

      // milestone juice
      final mile = (distance / 250).floor();
      if (mile > _mile) {
        _mile = mile;
        if (mile > 0) {
          audio.milestone();
          _toast('✨ ${mile * 250} m!');
        }
      }

      if (comboTimer > 0) {
        comboTimer -= dt;
        if (comboTimer <= 0) _setCombo(0);
      }

      score = distance.floor() + _starScore;
      _pushHud();
    }
  }

  int _starScore = 0;

  void collectSparkle(Vector2 at, bool bonus) {
    starsRun++;
    _setCombo(combo + 1);
    _starScore += (5 + combo) * (bonus ? 2 : 1);
    audio.collect(combo);
    world.add(sparkleBurst(at, bonus ? 10 : 6, BirjeColors.gold, scale: bonus ? 1.1 : 0.8));
  }

  void _setCombo(int v) {
    combo = v;
    if (v > maxCombo) maxCombo = v;
    if (v > 1) comboTimer = 2.2;
    comboN.value = v;
  }

  void gameOver() {
    if (!playing) return;
    state = GameState.over;
    audio.die();
    final skin = skinById(save.equipped);
    world.add(sparkleBurst(player.position.clone(), 26, skin.body, scale: 1.4));
    world.add(sparkleBurst(player.position.clone(), 14, Colors.white, scale: 1.1));
    player.removeFromParent();

    // economy
    final distBonus = (distance / 40).floor();
    earned = starsRun + distBonus;
    save.shards += earned;
    save.totalStars += starsRun;
    save.runs += 1;
    if (score > save.best) save.best = score;

    for (final a in _achievements) {
      if (!save.achievements.contains(a.id) && a.test(this)) {
        save.achievements.add(a.id);
        save.shards += a.reward;
        _toast('🏆 ${a.name}  +${a.reward}');
      }
    }
    save.save();
    shardsN.value = save.shards;

    overlays
      ..remove(Ov.hud)
      ..add(Ov.over);
  }

  void pause() {
    if (!playing) return;
    state = GameState.paused;
    overlays.add(Ov.pause);
  }

  void resume() {
    if (state != GameState.paused) return;
    state = GameState.playing;
    overlays.remove(Ov.pause);
  }

  void goMenu() {
    state = GameState.menu;
    world.removeWhere((_) => true);
    overlays
      ..remove(Ov.over)
      ..remove(Ov.pause)
      ..remove(Ov.hud)
      ..remove(Ov.shop)
      ..add(Ov.menu);
    shardsN.value = save.shards;
  }

  // ---------------------------- Shop -----------------------------
  /// Returns true on success (equipped or purchased).
  bool buyOrEquip(Skin s) {
    if (save.equipped == s.id) return false;
    if (save.unlocked.contains(s.id)) {
      save.equipped = s.id;
      audio.coin();
      save.save();
      return true;
    }
    if (save.shards >= s.price) {
      save.shards -= s.price;
      save.unlocked.add(s.id);
      save.equipped = s.id;
      audio.milestone();
      save.save();
      shardsN.value = save.shards;
      _toast('Unlocked ${s.name}! ✨');
      return true;
    }
    _toast('Not enough sparkles yet 🌟');
    return false;
  }

  void _pushHud() {
    scoreN.value = score;
    distN.value = distance.floor();
  }

  void _toast(String t) {
    toastN.value = t;
    Future.delayed(const Duration(milliseconds: 2600), () {
      if (toastN.value == t) toastN.value = null;
    });
  }
}
