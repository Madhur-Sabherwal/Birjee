import 'dart:math' as math;
import 'package:flame/components.dart';
import 'package:flame/particles.dart';
import 'package:flutter/material.dart';
import 'birje_game.dart';
import 'theme.dart';

/// Static gradient sky + drifting clouds + rainbows. Pure decoration (no
/// collision). Lives at the lowest priority so everything renders on top.
class SkyBackground extends PositionComponent with HasGameReference<BirjeGame> {
  SkyBackground() : super(priority: -10);
  final _rng = math.Random(7);
  late List<List<double>> _clouds; // x,y,scale,speed
  double _t = 0;

  @override
  Future<void> onLoad() async {
    size = game.size;
    _clouds = List.generate(
        9,
        (_) => [
              _rng.nextDouble() * game.size.x * 2,
              game.size.y * (0.05 + _rng.nextDouble() * 0.8),
              0.5 + _rng.nextDouble() * 0.9,
              0.04 + _rng.nextDouble() * 0.1
            ]);
  }

  @override
  void update(double dt) {
    _t += dt;
    if (game.playing) {
      for (final cl in _clouds) {
        cl[0] -= game.scrollSpeed * cl[3] * dt;
        if (cl[0] < -game.size.x * 0.3) cl[0] = game.size.x + _rng.nextDouble() * game.size.x * 0.5;
      }
    }
  }

  @override
  void render(Canvas c) {
    final w = game.size.x, h = game.size.y;
    c.drawRect(
        Rect.fromLTWH(0, 0, w, h),
        Paint()
          ..shader = const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [BirjeColors.skyTop, BirjeColors.skyMid, BirjeColors.skyLow],
            stops: [0, 0.55, 1],
          ).createShader(Rect.fromLTWH(0, 0, w, h)));

    _rainbow(c, w * 0.12, h * 0.42, w * 0.34);
    _rainbow(c, w * 0.92, h * 0.5, w * 0.32);

    final cloud = Paint()..color = Colors.white.withOpacity(.85);
    for (final cl in _clouds) {
      _cloud(c, cl[0], cl[1], cl[2], cloud);
    }
  }

  void _cloud(Canvas c, double x, double y, double s, Paint p) {
    final u = 22 * s;
    const offs = [
      [0.0, 0.0, 1.3],
      [-1.0, 0.27, 1.0],
      [1.0, 0.27, 1.0],
      [-0.5, -0.36, 0.9],
      [0.6, -0.27, 1.0]
    ];
    for (final o in offs) {
      c.drawCircle(Offset(x + o[0] * u, y + o[1] * u), u * o[2], p);
    }
  }

  void _rainbow(Canvas c, double cx, double cy, double r) {
    const cols = [
      Color(0xFFFF9DB4),
      Color(0xFFFFD86B),
      Color(0xFF8DE0C0),
      Color(0xFF9DB4FF),
      Color(0xFFC7B6FF)
    ];
    for (int i = 0; i < cols.length; i++) {
      c.drawArc(
          Rect.fromCircle(center: Offset(cx, cy), radius: r - i * r * 0.06),
          math.pi,
          math.pi,
          false,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = r * 0.06
            ..color = cols[i].withOpacity(.35));
    }
  }
}

/// Spawns a quick sparkle burst at [where]. Used on collect, flap, and poof.
ParticleSystemComponent sparkleBurst(Vector2 where, int n, Color color, {double scale = 1}) {
  final rng = math.Random();
  return ParticleSystemComponent(
    position: where,
    particle: Particle.generate(
      count: n,
      generator: (i) {
        final a = rng.nextDouble() * math.pi * 2;
        final sp = (40 + rng.nextDouble() * 160) * scale;
        return AcceleratedParticle(
          acceleration: Vector2(0, 240),
          speed: Vector2(math.cos(a) * sp, math.sin(a) * sp - 40),
          lifespan: 0.4 + rng.nextDouble() * 0.5,
          child: CircleParticle(
            radius: (2 + rng.nextDouble() * 3) * scale,
            paint: Paint()..color = color,
          ),
        );
      },
    ),
  );
}
