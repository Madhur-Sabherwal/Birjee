import 'dart:math' as math;
import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../birje_game.dart';
import '../theme.dart';
import 'pillar.dart';
import 'sparkle.dart';

/// The star of the show. One-tap physics + an expressive procedural drawing.
/// No image assets in v1 — everything is canvas, so it scales crisply on any
/// device and is trivial to recolour for skins.
class BirjePlayer extends PositionComponent
    with HasGameReference<BirjeGame>, CollisionCallbacks {
  double vy = 0;
  double rot = 0;
  double prop = 0; // propeller phase
  double squint = 0; // eye squint right after a flap
  double _idleT = 0;

  // Physics tuning, expressed relative to screen height for device independence.
  static const double gravity = 2.05; // * H per s^2
  static const double flapImpulse = -0.84; // * H per s
  static const double maxFall = 1.05; // * H per s

  BirjePlayer() : super(anchor: Anchor.center, priority: 10);

  double get r => math.min(game.size.x, game.size.y) * 0.052;

  @override
  Future<void> onLoad() async {
    size = Vector2.all(r * 2);
    position = Vector2(game.size.x * 0.30, game.size.y * 0.45);
    add(CircleHitbox(
      radius: r * 0.72, // kind hitbox
      anchor: Anchor.center,
      position: size / 2,
    ));
  }

  void flap() {
    vy = flapImpulse * game.size.y;
    squint = 0.5;
    prop += 1.2;
  }

  @override
  void update(double dt) {
    super.update(dt);
    prop += dt * (10 + (squint > 0 ? 16 : 0));
    squint = math.max(0, squint - dt * 2.2);

    if (!game.playing) return;

    if (game.started) {
      vy += gravity * game.size.y * dt;
      vy = math.min(vy, maxFall * game.size.y);
      position.y += vy * dt;
      rot = (vy / (game.size.y * 0.9)).clamp(-0.5, 0.9);
      // boundaries
      if (position.y - r < 0 || position.y + r > game.size.y) {
        game.gameOver();
      }
    } else {
      _idleT += dt;
      position.y = game.size.y * 0.45 + math.sin(_idleT * 2) * game.size.y * 0.02;
    }
  }

  @override
  void onCollisionStart(Set<Vector2> points, PositionComponent other) {
    super.onCollisionStart(points, other);
    if (!game.started) return;
    if (other is PillarSegment) {
      game.gameOver();
    } else if (other is Sparkle && !other.collected) {
      other.collected = true;
      game.collectSparkle(other.position.clone(), other.bonus);
      other.removeFromParent();
    }
  }

  // ----- Procedural drawing (ported 1:1 with the HTML prototype) -----
  @override
  void render(Canvas c) {
    final skin = skinById(game.save.equipped);
    final rr = r;
    c.save();
    c.translate(size.x / 2, size.y / 2);
    c.rotate(rot);

    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(2, rr * 0.07)
      ..color = const Color(0x8C3A3357);

    if (skin.glow != null) {
      c.drawCircle(
          Offset.zero,
          rr * 1.15,
          Paint()
            ..color = skin.glow!.withOpacity(.35)
            ..maskFilter = MaskFilter.blur(BlurStyle.normal, rr * 0.6));
    }

    final body = Paint()..color = skin.body;
    // feet
    for (final s in [-1, 1]) {
      c.drawOval(
          Rect.fromCenter(center: Offset(s * rr * 0.42, rr * 0.96), width: rr * 0.52, height: rr * 0.4),
          body);
    }
    // body
    c.drawOval(Rect.fromCenter(center: Offset.zero, width: rr * 2.08, height: rr * 2.0), body);
    c.drawOval(Rect.fromCenter(center: Offset.zero, width: rr * 2.08, height: rr * 2.0), stroke);
    // belly
    c.drawOval(Rect.fromCenter(center: Offset(0, rr * 0.22), width: rr * 1.24, height: rr * 1.32),
        Paint()..color = skin.belly);
    // cheeks
    final blush = Paint()..color = const Color(0xD9F79DB4);
    c.drawOval(Rect.fromCenter(center: Offset(-rr * 0.5, rr * 0.08), width: rr * 0.4, height: rr * 0.26), blush);
    c.drawOval(Rect.fromCenter(center: Offset(rr * 0.5, rr * 0.08), width: rr * 0.4, height: rr * 0.26), blush);

    // eyes
    final eyeY = -rr * 0.12, eyeX = rr * 0.34;
    final dark = Paint()..color = const Color(0xFF2A2540);
    final white = Paint()..color = Colors.white;
    for (final s in [-1, 1]) {
      c.save();
      c.translate(s * eyeX, eyeY);
      if (squint > 0.5) {
        final p = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(2, rr * 0.09)
          ..strokeCap = StrokeCap.round
          ..color = BirjeColors.ink;
        c.drawArc(Rect.fromCircle(center: Offset(0, rr * 0.06), radius: rr * 0.2),
            math.pi * 1.15, math.pi * 0.7, false, p);
      } else {
        c.drawOval(Rect.fromCenter(center: Offset.zero, width: rr * 0.4, height: rr * 0.52), dark);
        c.drawOval(Rect.fromCenter(center: Offset(-rr * 0.06, -rr * 0.08), width: rr * 0.14, height: rr * 0.18), white);
        c.drawOval(Rect.fromCenter(center: Offset(rr * 0.07, rr * 0.05), width: rr * 0.07, height: rr * 0.09), white);
      }
      c.restore();
    }
    // nose + smile
    c.drawOval(Rect.fromCenter(center: Offset(0, rr * 0.06), width: rr * 0.14, height: rr * 0.1),
        Paint()..color = BirjeColors.ink);
    c.drawArc(
        Rect.fromCircle(center: Offset(0, rr * 0.10), radius: rr * 0.16),
        0.2,
        math.pi - 0.4,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(2, rr * 0.055)
          ..strokeCap = StrokeCap.round
          ..color = BirjeColors.ink);

    // ----- beanie -----
    c.save();
    c.translate(0, -rr * 0.62);
    final band = RRect.fromRectAndRadius(
        Rect.fromLTWH(-rr * 0.92, -rr * 0.02, rr * 1.84, rr * 0.42), Radius.circular(rr * 0.18));
    c.drawRRect(band, Paint()..color = skin.band);
    c.drawRRect(band, stroke);
    final dome = Path()
      ..moveTo(-rr * 0.86, 0)
      ..quadraticBezierTo(-rr * 0.7, -rr * 0.95, 0, -rr * 0.98)
      ..quadraticBezierTo(rr * 0.7, -rr * 0.95, rr * 0.86, 0)
      ..close();
    c.drawPath(
        dome,
        Paint()
          ..shader = LinearGradient(colors: [skin.hat, skin.dome2])
              .createShader(Rect.fromLTWH(-rr, -rr, rr * 2, rr)));
    c.drawPath(dome, stroke);
    // stalk + propeller
    c.drawLine(Offset(0, -rr * 0.98), Offset(0, -rr * 1.28),
        Paint()..color = const Color(0xFFC4577E)..strokeWidth = math.max(2, rr * 0.09)..strokeCap = StrokeCap.round);
    c.save();
    c.translate(0, -rr * 1.30);
    final w = math.cos(prop).abs();
    for (final s in [-1, 1]) {
      c.drawOval(
          Rect.fromCenter(center: Offset(s * rr * 0.42 * w, 0), width: rr * 0.84, height: rr * 0.32),
          Paint()..color = s < 0 ? const Color(0xFFCFE8F2) : Colors.white);
    }
    c.drawCircle(Offset.zero, rr * 0.09, Paint()..color = const Color(0xFFC4577E));
    c.restore();
    c.restore();

    c.restore();
  }
}
