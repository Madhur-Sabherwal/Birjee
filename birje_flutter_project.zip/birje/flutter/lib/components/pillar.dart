import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import 'scroll_component.dart';

/// One solid fluffy cloud column (either above or below a gap).
/// Collision = game over. Drawn as a rounded cloud, never a hard "pipe".
class PillarSegment extends ScrollComponent with CollisionCallbacks {
  final bool fromTop;
  PillarSegment({
    required double x,
    required double y,
    required double w,
    required double h,
    required this.fromTop,
  }) : super(position: Vector2(x, y), size: Vector2(w, h), priority: 5);

  @override
  Future<void> onLoad() async {
    // Slightly forgiving hitbox (kinder than the visual) feels fair & fun.
    add(RectangleHitbox(
      size: Vector2(width * 0.82, height),
      position: Vector2(width * 0.09, 0),
      collisionType: CollisionType.passive,
    ));
  }

  static final _fill = Paint()..color = const Color(0xFFF4F1FF);
  static final _bump = Paint()..color = const Color(0xFFFFFFFF);
  static final _shade = Paint()..color = const Color(0x2E9DB4FF);

  @override
  void render(Canvas c) {
    final r = RRect.fromRectAndRadius(
        Rect.fromLTWH(0, -10, width, height + 20), Radius.circular(width * 0.4));
    c.drawRRect(r, _fill);
    c.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(width * 0.6, -10, width * 0.4, height + 20),
            Radius.circular(width * 0.3)),
        _shade);
    // bumpy edge facing the gap
    final edgeY = fromTop ? height : 0.0;
    for (int i = 0; i <= 3; i++) {
      c.drawCircle(Offset(width * (i / 3), edgeY), width * 0.26, _bump);
    }
  }
}
