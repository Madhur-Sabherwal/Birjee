import 'package:flame/components.dart';
import '../birje_game.dart';

/// Anything that scrolls leftward with the world inherits this.
/// Centralising the scroll keeps every element perfectly in sync and makes
/// the difficulty ramp (game.scrollSpeed) affect the whole world at once.
abstract class ScrollComponent extends PositionComponent
    with HasGameReference<BirjeGame> {
  ScrollComponent({super.position, super.size, super.anchor, super.priority});

  @override
  void update(double dt) {
    super.update(dt);
    if (game.playing) {
      position.x -= game.scrollSpeed * dt;
      if (position.x + width < -40) removeFromParent();
    }
  }
}
