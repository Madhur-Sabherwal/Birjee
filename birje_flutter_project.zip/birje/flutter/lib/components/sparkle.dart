import 'dart:math' as math;
import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import 'scroll_component.dart';

/// A glowing collectible. `bonus` ones are worth more (risk/reward placement).
class Sparkle extends ScrollComponent with CollisionCallbacks {
  final bool bonus;
  bool collected = false;
  double _t = math.Random().nextDouble() * 6;

  Sparkle({required double x, required double y, required double r, this.bonus = false})
      : super(
            position: Vector2(x, y),
            size: Vector2.all(r * 2),
            anchor: Anchor.center,
            priority: 6);

  @override
  Future<void> onLoad() async {
    add(CircleHitbox(
      radius: width * 0.9,
      anchor: Anchor.center,
      position: size / 2,
      collisionType: CollisionType.passive,
    ));
  }

  @override
  void update(double dt) {
    super.update(dt);
    _t += dt;
  }

  late final Paint _core = Paint()
    ..color = bonus ? const Color(0xFFFFB36B) : const Color(0xFFFFD86B)
    ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
  final Paint _inner = Paint()..color = const Color(0xD9FFFFFF);

  @override
  void render(Canvas c) {
    if (collected) return;
    final pulse = 1 + math.sin(_t * 4) * 0.12;
    final cx = width / 2, cy = height / 2;
    _drawStar(c, cx, cy, (width / 2) * pulse, 5, _core);
    _drawStar(c, cx, cy, (width / 4) * pulse, 5, _inner);
  }

  void _drawStar(Canvas c, double cx, double cy, double r, int pts, Paint p) {
    final path = Path();
    for (int i = 0; i < pts * 2; i++) {
      final rad = i.isEven ? r : r * 0.45;
      final a = math.pi / pts * i - math.pi / 2;
      final x = cx + math.cos(a) * rad, y = cy + math.sin(a) * rad;
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
    }
    path.close();
    c.drawPath(path, p);
  }
}
