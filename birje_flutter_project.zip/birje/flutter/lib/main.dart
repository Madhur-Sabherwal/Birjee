import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'birje_game.dart';
import 'theme.dart';
import 'ui/overlays.dart';

/// Birje — Hop, Flap, Sparkle!
/// A wholesome one-tap endless sky-flyer.
///
/// Entry point: locks portrait, builds the Flame [BirjeGame], and wraps the
/// GameWidget in a full-screen tap catcher so a tap *anywhere* makes Birje flap.
/// Overlay buttons (Play / Shop / Pause …) sit on top and absorb their own taps,
/// so tapping a button does not also trigger a flap.
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const BirjeApp());
}

class BirjeApp extends StatelessWidget {
  const BirjeApp({super.key});

  @override
  Widget build(BuildContext context) {
    // One long-lived game instance.
    final game = BirjeGame();

    return MaterialApp(
      title: 'Birje',
      debugShowCheckedModeBanner: false,
      // If you bundle the "Baloo 2" font (see README → Fonts), set:
      //   theme: ThemeData(fontFamily: 'Baloo2'),
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: BirjeColors.skyTop,
      ),
      home: Scaffold(
        body: GestureDetector(
          // opaque => empty sky areas still register taps.
          behavior: HitTestBehavior.opaque,
          onTapDown: (_) => game.onScreenTap(),
          child: GameWidget<BirjeGame>(
            game: game,
            overlayBuilderMap: overlayBuilderMap(),
            // Menu overlay is also added in BirjeGame.onLoad; listing it here
            // means it is present from the very first frame.
            initialActiveOverlays: const [Ov.menu],
          ),
        ),
      ),
    );
  }
}
