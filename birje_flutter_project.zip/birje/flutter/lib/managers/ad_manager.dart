/// OPTIONAL future monetization — disabled by default. The game is fully
/// playable and fair without ads. When you're ready:
///   1. uncomment google_mobile_ads in pubspec.yaml
///   2. add your AdMob app id to Android/iOS native config
///   3. implement the two methods below and call them from the Game Over
///      overlay ("Watch for +bonus sparkles" / "Continue this run").
///
/// Ethics guardrails baked in by design:
///   - Rewarded only (player opts in), never interstitials mid-run.
///   - Rewards are cosmetic currency or a single continue — never pay-to-win.
class AdManager {
  bool get isReady => false;

  Future<void> init() async {/* MobileAds.instance.initialize(); */}

  /// Show a rewarded ad. Returns true if the reward should be granted.
  Future<bool> showRewarded() async => false;
}
