/// Thin audio wrapper. Ships as a safe no-op so the prototype runs with zero
/// audio assets. To enable sound:
///   1. uncomment flame_audio in pubspec.yaml
///   2. add files under assets/audio/ (flap.wav, collect.wav, milestone.wav,
///      poof.wav, coin.wav) and the assets: block in pubspec.yaml
///   3. uncomment the FlameAudio calls below.
///
/// Keeping this isolated means the rest of the game never has to care whether
/// audio is wired up yet.
class AudioManager {
  bool muted = false;

  Future<void> preload() async {
    // await FlameAudio.audioCache.loadAll(
    //   ['flap.wav','collect.wav','milestone.wav','poof.wav','coin.wav']);
  }

  void _play(String file, {double volume = 1}) {
    if (muted) return;
    // FlameAudio.play(file, volume: volume);
  }

  void flap() => _play('flap.wav', volume: 0.5);
  void collect(int combo) => _play('collect.wav', volume: 0.5);
  void milestone() => _play('milestone.wav');
  void die() => _play('poof.wav');
  void coin() => _play('coin.wav', volume: 0.4);
}
