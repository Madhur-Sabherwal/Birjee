import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Local-only persistence. No accounts, no servers, no analytics.
/// Stores a single JSON blob under one key for easy versioning/migration.
class SaveManager {
  static const _key = 'birje_save_v1';
  SharedPreferences? _prefs;

  int best = 0;
  int shards = 0;
  int totalStars = 0;
  int runs = 0;
  String equipped = 'classic';
  Set<String> unlocked = {'classic'};
  String? lastDaily; // 'YYYY-MM-DD'
  Set<String> achievements = {};

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs!.getString(_key);
    if (raw == null) return;
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      best = m['best'] ?? 0;
      shards = m['shards'] ?? 0;
      totalStars = m['totalStars'] ?? 0;
      runs = m['runs'] ?? 0;
      equipped = m['equipped'] ?? 'classic';
      unlocked = Set<String>.from(m['unlocked'] ?? ['classic']);
      lastDaily = m['lastDaily'];
      achievements = Set<String>.from(m['ach'] ?? []);
    } catch (_) {/* corrupt save -> start fresh, never crash */}
  }

  Future<void> save() async {
    await _prefs?.setString(
        _key,
        jsonEncode({
          'best': best,
          'shards': shards,
          'totalStars': totalStars,
          'runs': runs,
          'equipped': equipped,
          'unlocked': unlocked.toList(),
          'lastDaily': lastDaily,
          'ach': achievements.toList(),
        }));
  }

  /// Returns the daily bonus granted (0 if already claimed today).
  int claimDailyIfNew() {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (lastDaily != today) {
      lastDaily = today;
      shards += 20;
      save();
      return 20;
    }
    return 0;
  }
}
