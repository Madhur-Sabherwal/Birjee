import 'package:flutter/material.dart';

/// Central palette. Pastel sky world, candy UI. All original.
class BirjeColors {
  static const skyTop = Color(0xFF9DB4FF);
  static const skyMid = Color(0xFFC9B8FF);
  static const skyLow = Color(0xFFFFC9DD);
  static const gold = Color(0xFFFFD86B);
  static const goldDeep = Color(0xFFF4B23C);
  static const ink = Color(0xFF3A3357);
  static const candy = Color(0xFFFF8FB1);
  static const candyDeep = Color(0xFFE86C95);
  static const mint = Color(0xFF8DE0C0);
  static const panel = Color(0xFFFFFFFF);
}

/// A cosmetic skin. NEVER affects gameplay (no pay-to-win).
class Skin {
  final String id;
  final String name;
  final int price;
  final Color body, belly, hat, band, dome2;
  final Color? glow;
  const Skin(this.id, this.name, this.price, this.body, this.belly, this.hat,
      this.band, this.dome2,
      {this.glow});
}

const List<Skin> kSkins = [
  Skin('classic', 'Classic', 0, Color(0xFF7FD4E8), Color(0xFFFFFFFF),
      Color(0xFFFFD86B), Color(0xFFB97A4A), Color(0xFFF79DB4)),
  Skin('bubblegum', 'Bubblegum', 60, Color(0xFFFFB3D1), Color(0xFFFFF4FA),
      Color(0xFFFF8FB1), Color(0xFFC75E86), Color(0xFFFFE08A)),
  Skin('matcha', 'Matcha', 60, Color(0xFFA7E0B0), Color(0xFFF4FFF0),
      Color(0xFF8DE0C0), Color(0xFF5E9A6F), Color(0xFFFFE08A)),
  Skin('lavender', 'Lavender', 90, Color(0xFFC7B6FF), Color(0xFFF6F2FF),
      Color(0xFF9D8CFF), Color(0xFF6F5FC6), Color(0xFFFFC9DD)),
  Skin('peach', 'Peachy', 90, Color(0xFFFFC79A), Color(0xFFFFF6EC),
      Color(0xFFFFB36B), Color(0xFFC97F3E), Color(0xFFFF9DB4)),
  Skin('cloud', 'Cloud', 120, Color(0xFFE8EEFF), Color(0xFFFFFFFF),
      Color(0xFFB9C7FF), Color(0xFF8A98D6), Color(0xFFFFD86B)),
  Skin('sunset', 'Sunset', 150, Color(0xFFFF9E80), Color(0xFFFFF0E6),
      Color(0xFFFF6B9D), Color(0xFFC4577E), Color(0xFFFFD86B)),
  Skin('galaxy', 'Galaxy', 240, Color(0xFF8C7BE0), Color(0xFFE9E4FF),
      Color(0xFF6F5FC6), Color(0xFF463A8C), Color(0xFFFFD86B),
      glow: Color(0xFFC9B8FF)),
  Skin('gold', 'Sunbeam', 400, Color(0xFFFFD86B), Color(0xFFFFF6D6),
      Color(0xFFFFB36B), Color(0xFFD99A2E), Color(0xFFFF9DB4),
      glow: Color(0xFFFFE9B0)),
];

Skin skinById(String id) => kSkins.firstWhere((s) => s.id == id,
    orElse: () => kSkins.first);
