import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'birje_game.dart';
import 'theme.dart';

// ----------------------------- Shared bits -----------------------------
class _CandyButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color, shadow, text;
  final double size;
  const _CandyButton(this.label, this.onTap,
      {this.color = BirjeColors.candy,
      this.shadow = const Color(0xFFC4577E),
      this.text = Colors.white,
      this.size = 22});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(999),
          boxShadow: [BoxShadow(color: shadow, offset: const Offset(0, 5))],
        ),
        child: Text(label,
            style: TextStyle(
                color: text, fontWeight: FontWeight.w800, fontSize: size, letterSpacing: .5)),
      ),
    );
  }
}

class _ShardChip extends StatelessWidget {
  final int value;
  const _ShardChip(this.value);
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 16, 8),
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(.92), borderRadius: BorderRadius.circular(999)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.star_rounded, color: BirjeColors.gold, size: 22),
        const SizedBox(width: 6),
        Text('$value',
            style: const TextStyle(
                color: BirjeColors.ink, fontWeight: FontWeight.w800, fontSize: 18)),
      ]),
    );
  }
}

/// Compact procedural Birje for shop thumbnails.
class BirjeThumb extends StatelessWidget {
  final Skin skin;
  final double size;
  const BirjeThumb(this.skin, {this.size = 60, super.key});
  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size.square(size), painter: _ThumbPainter(skin));
}

class _ThumbPainter extends CustomPainter {
  final Skin skin;
  _ThumbPainter(this.skin);
  @override
  void paint(Canvas c, Size s) {
    final r = s.width * 0.32;
    c.translate(s.width / 2, s.height * 0.58);
    c.drawOval(Rect.fromCenter(center: Offset.zero, width: r * 2, height: r * 1.95),
        Paint()..color = skin.body);
    c.drawOval(Rect.fromCenter(center: Offset(0, r * 0.22), width: r * 1.2, height: r * 1.3),
        Paint()..color = skin.belly);
    for (final sgn in [-1, 1]) {
      c.drawOval(
          Rect.fromCenter(center: Offset(sgn * r * 0.32, -r * 0.1), width: r * 0.34, height: r * 0.46),
          Paint()..color = const Color(0xFF2A2540));
    }
    // beanie
    c.save();
    c.translate(0, -r * 0.62);
    c.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(-r * 0.9, -r * 0.02, r * 1.8, r * 0.4), Radius.circular(r * 0.18)),
        Paint()..color = skin.band);
    final dome = Path()
      ..moveTo(-r * 0.84, 0)
      ..quadraticBezierTo(-r * 0.7, -r * 0.9, 0, -r * 0.95)
      ..quadraticBezierTo(r * 0.7, -r * 0.9, r * 0.84, 0)
      ..close();
    c.drawPath(dome, Paint()..color = skin.hat);
    c.drawCircle(Offset(0, -r * 1.2), r * 0.1, Paint()..color = const Color(0xFFC4577E));
    c.restore();
  }

  @override
  bool shouldRepaint(_) => false;
}

// ----------------------------- Overlays -----------------------------
Map<String, Widget Function(BuildContext, BirjeGame)> overlayBuilderMap() => {
      Ov.menu: (ctx, g) => MenuOverlay(g),
      Ov.hud: (ctx, g) => HudOverlay(g),
      Ov.over: (ctx, g) => GameOverOverlay(g),
      Ov.pause: (ctx, g) => PauseOverlay(g),
      Ov.shop: (ctx, g) => ShopOverlay(g),
    };

class MenuOverlay extends StatelessWidget {
  final BirjeGame g;
  const MenuOverlay(this.g, {super.key});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('Birje',
            style: TextStyle(
                fontSize: 96, fontWeight: FontWeight.w800, color: Colors.white, height: .9)),
        const Text('Hop, Flap, Sparkle!',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Colors.white)),
        const SizedBox(height: 28),
        _CandyButton('Play', g.startRun, size: 24),
        const SizedBox(height: 16),
        Row(mainAxisSize: MainAxisSize.min, children: [
          _CandyButton('Shop', () => g.overlays.add(Ov.shop),
              color: BirjeColors.mint, shadow: const Color(0xFF4BA588), text: const Color(0xFF0D4D3A), size: 18),
          const SizedBox(width: 12),
          ValueListenableBuilder(valueListenable: g.shardsN, builder: (_, v, __) => _ShardChip(v)),
        ]),
        const SizedBox(height: 16),
        const Text('Tap anywhere to flap ✨',
            style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class HudOverlay extends StatelessWidget {
  final BirjeGame g;
  const HudOverlay(this.g, {super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                ValueListenableBuilder(
                    valueListenable: g.scoreN,
                    builder: (_, v, __) => Text('$v',
                        style: const TextStyle(
                            fontSize: 56, fontWeight: FontWeight.w800, color: Colors.white, height: 1))),
                ValueListenableBuilder(
                    valueListenable: g.distN,
                    builder: (_, v, __) => Text('$v m',
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white70))),
              ]),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              GestureDetector(
                onTap: g.pause,
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.92), borderRadius: BorderRadius.circular(14)),
                  child: const Icon(Icons.pause_rounded, color: BirjeColors.ink),
                ),
              ),
              const SizedBox(height: 8),
              ValueListenableBuilder(
                valueListenable: g.comboN,
                builder: (_, v, __) => v > 1
                    ? Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                            color: BirjeColors.gold, borderRadius: BorderRadius.circular(999)),
                        child: Text('x$v',
                            style: const TextStyle(
                                color: Color(0xFF5B3D04), fontWeight: FontWeight.w800)))
                    : const SizedBox.shrink(),
              ),
            ]),
          ]),
          const Spacer(),
          ValueListenableBuilder(
            valueListenable: g.toastN,
            builder: (_, t, __) => t == null
                ? const SizedBox.shrink()
                : Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                          color: Colors.white.withOpacity(.95),
                          borderRadius: BorderRadius.circular(16)),
                      child: Text(t,
                          style: const TextStyle(
                              color: BirjeColors.ink, fontWeight: FontWeight.w700)),
                    ),
                  ),
          ),
        ]),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String k, v;
  final Color? color;
  const _Stat(this.k, this.v, {this.color});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFF4F1FF), borderRadius: BorderRadius.circular(18)),
      child: Column(children: [
        Text(k.toUpperCase(),
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF8B83A8))),
        Text(v,
            style: TextStyle(
                fontSize: 26, fontWeight: FontWeight.w800, color: color ?? BirjeColors.ink, height: 1)),
      ]),
    );
  }
}

class GameOverOverlay extends StatelessWidget {
  final BirjeGame g;
  const GameOverOverlay(this.g, {super.key});
  @override
  Widget build(BuildContext context) {
    final isPB = g.score >= g.save.best && g.score > 0;
    final title = isPB
        ? 'Sparkling run!'
        : g.distance < 80
            ? 'Whoops! Try again'
            : g.distance < 300
                ? 'Nice flight!'
                : 'Amazing flight!';
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 380),
        margin: const EdgeInsets.symmetric(horizontal: 22),
        padding: const EdgeInsets.fromLTRB(22, 26, 22, 22),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(34),
            border: Border.all(color: Colors.white, width: 4)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (isPB)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                  color: BirjeColors.gold, borderRadius: BorderRadius.circular(999)),
              child: const Text('✨ New Best! ✨',
                  style: TextStyle(color: Color(0xFF5B3D04), fontWeight: FontWeight.w800)),
            ),
          Text(title,
              style: const TextStyle(
                  fontSize: 30, fontWeight: FontWeight.w800, color: BirjeColors.ink)),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: _Stat('Score', '${g.score}')),
            const SizedBox(width: 10),
            Expanded(child: _Stat('Best', '${g.save.best}', color: BirjeColors.goldDeep)),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _Stat('Distance', '${g.distance.floor()} m')),
            const SizedBox(width: 10),
            Expanded(child: _Stat('Sparkles', '${g.starsRun}')),
          ]),
          const SizedBox(height: 14),
          Text('+${g.earned} sparkles earned',
              style: const TextStyle(
                  color: BirjeColors.goldDeep, fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 14),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            _CandyButton('Fly Again', g.startRun,
                color: BirjeColors.gold,
                shadow: const Color(0xFFD99A2E),
                text: const Color(0xFF5B3D04)),
            const SizedBox(width: 10),
            _CandyButton('Shop', () => g.overlays.add(Ov.shop),
                color: BirjeColors.mint,
                shadow: const Color(0xFF4BA588),
                text: const Color(0xFF0D4D3A),
                size: 16),
          ]),
          const SizedBox(height: 10),
          GestureDetector(
              onTap: g.goMenu,
              child: const Text('Menu',
                  style: TextStyle(color: Color(0xFF8B83A8), fontWeight: FontWeight.w700))),
        ]),
      ),
    );
  }
}

class PauseOverlay extends StatelessWidget {
  final BirjeGame g;
  const PauseOverlay(this.g, {super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(.25),
      child: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Paused',
              style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: Colors.white)),
          const SizedBox(height: 18),
          _CandyButton('Resume', g.resume),
          const SizedBox(height: 12),
          GestureDetector(
              onTap: g.goMenu,
              child: const Text('Main Menu',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16))),
        ]),
      ),
    );
  }
}

class ShopOverlay extends StatefulWidget {
  final BirjeGame g;
  const ShopOverlay(this.g, {super.key});
  @override
  State<ShopOverlay> createState() => _ShopOverlayState();
}

class _ShopOverlayState extends State<ShopOverlay> {
  @override
  Widget build(BuildContext context) {
    final g = widget.g;
    return Container(
      color: Colors.black.withOpacity(.2),
      child: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 400),
          margin: const EdgeInsets.symmetric(horizontal: 18),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(34)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text("Birje's Wardrobe",
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: BirjeColors.ink)),
            const SizedBox(height: 10),
            ValueListenableBuilder(valueListenable: g.shardsN, builder: (_, v, __) => _ShardChip(v)),
            const SizedBox(height: 14),
            Flexible(
              child: GridView.count(
                shrinkWrap: true,
                crossAxisCount: 3,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                children: kSkins.map((s) {
                  final owned = g.save.unlocked.contains(s.id);
                  final equipped = g.save.equipped == s.id;
                  return GestureDetector(
                    onTap: () => setState(() => g.buyOrEquip(s)),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: equipped ? const Color(0xFFE9FBF3) : const Color(0xFFF4F1FF),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: equipped ? BirjeColors.mint : Colors.transparent, width: 3),
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        BirjeThumb(s, size: 54),
                        Text(s.name,
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w700, color: BirjeColors.ink)),
                        if (equipped)
                          const Text('Wearing',
                              style: TextStyle(
                                  fontSize: 11, fontWeight: FontWeight.w800, color: Color(0xFF3AA589)))
                        else if (owned)
                          const Text('Wear',
                              style: TextStyle(
                                  fontSize: 11, fontWeight: FontWeight.w700, color: BirjeColors.mint))
                        else
                          Text('✦ ${s.price}',
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w800, color: BirjeColors.goldDeep)),
                      ]),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 14),
            _CandyButton('Done', () => g.overlays.remove(Ov.shop), size: 18),
          ]),
        ),
      ),
    );
  }
}
