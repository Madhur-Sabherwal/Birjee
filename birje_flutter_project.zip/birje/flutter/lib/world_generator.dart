import 'dart:math' as math;
import 'package:flame/components.dart';
import 'birje_game.dart';
import 'components/pillar.dart';
import 'components/sparkle.dart';

/// Owns procedural generation. Uses a seeded Random so a run is reproducible
/// (handy for testing / future "daily challenge" seeds), while still feeling
/// fresh because the seed changes every run.
class WorldGenerator {
  final BirjeGame game;
  late math.Random _rng;
  double _spawnX = 0;

  static const double pillarGapX = 0.62; // spacing as fraction of width
  static const double gapStart = 0.34; // gap height fraction of height
  static const double gapMin = 0.22;

  WorldGenerator(this.game);

  void reset({int? seed}) {
    _rng = math.Random(seed ?? DateTime.now().millisecondsSinceEpoch);
    final w = game.size.x;
    double x = w * 1.0;
    for (int i = 0; i < 4; i++) {
      _spawn(x);
      x += w * pillarGapX;
    }
    _spawnX = x;
  }

  /// Called each frame; spawns pillars as the world scrolls.
  void tick(double dt) {
    _spawnX -= game.scrollSpeed * dt;
    while (_spawnX < game.size.x) {
      _spawn(_spawnX);
      _spawnX += game.size.x * pillarGapX;
    }
  }

  void _spawn(double x) {
    final w = game.size.x, h = game.size.y;
    // gap shrinks slowly with distance -> rising mastery curve, but bounded.
    final gapFrac = math.max(gapMin, gapStart - game.distance * 0.00006);
    final gapH = h * gapFrac;
    final margin = h * 0.12;
    final gapY = margin + gapH / 2 + _rng.nextDouble() * (h - 2 * margin - gapH);

    final pw = w * 0.16;
    game.world.add(PillarSegment(x: x, y: 0, w: pw, h: gapY - gapH / 2, fromTop: true));
    game.world.add(PillarSegment(
        x: x, y: gapY + gapH / 2, w: pw, h: h - (gapY + gapH / 2), fromTop: false));

    // sparkle line through the gap
    final n = 3 + (_rng.nextBool() ? 0 : _rng.nextInt(3));
    final sr = math.min(w, h) * 0.024;
    for (int i = 0; i < n; i++) {
      game.world.add(Sparkle(
          x: x + w * 0.02 + i * (w * 0.045),
          y: gapY + math.sin(i * 1.1) * gapH * 0.18,
          r: sr));
    }
    // occasional bonus cluster (risk/reward)
    if (_rng.nextDouble() < 0.25) {
      final by = gapY + (_rng.nextBool() ? -1 : 1) * gapH * 0.55;
      if (by > margin && by < h - margin) {
        for (int i = 0; i < 3; i++) {
          game.world.add(Sparkle(x: x + w * 0.05 + i * w * 0.04, y: by, r: sr, bonus: true));
        }
      }
    }
  }
}
